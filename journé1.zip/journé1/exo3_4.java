public class exo3_4 {
    public static void main(String[] args) {
        for (int i =1 ; i <=10; i++  ){
            System.out.println(i);
        }
    }
    x
}
